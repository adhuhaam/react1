# Change Log
All notable changes to `React Material Dashboard Laravel` will be documented in this file.

## [1.0.0]
### Original Release
- Material Dashboard React 2
- Login
- Register
- Forgot password
- Profile edit
